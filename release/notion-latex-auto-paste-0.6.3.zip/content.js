(() => {
                                  
               
                   
                    
 

                         
               
                    
 

                     
               
                
                     
                      
                   
 

const DELIMITERS              = [
  { open: "$$", close: "$$", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\[", close: "\\]", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\(", close: "\\)", outputOpen: "$$", outputClose: "$$", display: false },
  { open: "$", close: "$", outputOpen: "$$", outputClose: "$$", display: false }
];

/**
 * Makes copied LaTeX compatible with Notion without changing surrounding prose.
 * Fenced and inline code are intentionally opaque.
 */
function normalizeLatexForNotion(input        )                  {
  const segments = splitFencedCode(input);
  let mathCount = 0;

  const text = segments
    .map((segment) => {
      if (segment.code) {
        return segment.text;
      }

      const result = normalizeTextSegment(segment.text);
      mathCount += result.mathCount;
      return result.text;
    })
    .join("");

  return {
    text,
    changed: text !== input,
    mathCount
  };
}

function splitFencedCode(input        )                                         {
  const lines = input.match(/[^\r\n]*(?:\r\n|\n|\r|$)/g)?.filter(Boolean) ?? [];
  const segments                                         = [];
  let buffer = "";
  let inFence = false;
  let fenceCharacter = "";
  let fenceLength = 0;

  const flush = (code         ) => {
    if (buffer) {
      segments.push({ text: buffer, code });
      buffer = "";
    }
  };

  for (const line of lines) {
    let openedThisLine = false;
    if (!inFence) {
      const opening = line.match(/^ {0,3}(`{3,}|~{3,})/);
      if (opening) {
        flush(false);
        inFence = true;
        openedThisLine = true;
        fenceCharacter = opening[1][0];
        fenceLength = opening[1].length;
      }
    }

    buffer += line;

    if (inFence && !openedThisLine) {
      const closingPattern = new RegExp(`^ {0,3}${escapeRegExp(fenceCharacter)}{${fenceLength},}\\s*$`);
      if (closingPattern.test(line.replace(/(?:\r\n|\n|\r)$/, ""))) {
        flush(true);
        inFence = false;
        fenceCharacter = "";
        fenceLength = 0;
      }
    }
  }

  flush(inFence);
  return segments;
}

function normalizeTextSegment(input        )                {
  let output = "";
  let mathCount = 0;
  let index = 0;

  while (index < input.length) {
    if (input[index] === "`") {
      const codeEnd = findInlineCodeEnd(input, index);
      if (codeEnd !== -1) {
        output += input.slice(index, codeEnd);
        index = codeEnd;
        continue;
      }
    }

    const delimiter = delimiterAt(input, index);
    if (!delimiter || !isValidOpening(input, index, delimiter)) {
      output += input[index];
      index += 1;
      continue;
    }

    const bodyStart = index + delimiter.open.length;
    const closingIndex = findClosingDelimiter(input, bodyStart, delimiter);
    if (closingIndex === -1) {
      output += input[index];
      index += 1;
      continue;
    }

    const body = input.slice(bodyStart, closingIndex);
    if (!isValidMathBody(body)) {
      output += input[index];
      index += 1;
      continue;
    }

    const normalizedBody = collapsePhysicalLineBreaks(body);
    output += `${delimiter.outputOpen}${normalizedBody}${delimiter.outputClose}`;
    mathCount += 1;
    index = closingIndex + delimiter.close.length;
  }

  return { text: output, mathCount };
}

function delimiterAt(input        , index        )                        {
  if (isEscaped(input, index)) {
    return undefined;
  }

  return DELIMITERS.find((delimiter) => input.startsWith(delimiter.open, index));
}

function isValidOpening(input        , index        , delimiter           )          {
  if (delimiter.open !== "$") {
    return true;
  }

  const previous = input[index - 1] ?? "";
  const next = input[index + 1] ?? "";
  return !/[A-Za-z0-9\\]/.test(previous) && next !== "$" && !/\s/.test(next);
}

function findClosingDelimiter(input        , start        , delimiter           )         {
  for (let index = start; index <= input.length - delimiter.close.length; index += 1) {
    if (!input.startsWith(delimiter.close, index) || isEscaped(input, index)) {
      continue;
    }

    if (delimiter.close === "$" && input[index + 1] === "$") {
      continue;
    }

    if (delimiter.close === "$") {
      const previous = input[index - 1] ?? "";
      const next = input[index + 1] ?? "";
      if (/\s/.test(previous) || /[0-9]/.test(next)) {
        continue;
      }
    }

    return index;
  }

  return -1;
}

function isValidMathBody(body        )          {
  const trimmed = body.trim();
  return trimmed.length > 0 && !/(?:\r\n|\n|\r)[ \t]*(?:\r\n|\n|\r)/.test(trimmed);
}

function collapsePhysicalLineBreaks(body        )         {
  return body.replace(/[ \t]*(?:\r\n|\n|\r)[ \t]*/g, " ").trim();
}

function findInlineCodeEnd(input        , start        )         {
  let markerLength = 1;
  while (input[start + markerLength] === "`") {
    markerLength += 1;
  }

  const marker = "`".repeat(markerLength);
  const end = input.indexOf(marker, start + markerLength);
  return end === -1 ? -1 : end + markerLength;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function escapeRegExp(value        )         {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

                               
               
                   
 

                                     
                 
                  
 

                                  
               
                                 
 

                                 
                     
                      
                   
                    
 

/**
 * Replaces formulas with plain, Markdown-safe markers for the first paste.
 * Once Notion has created its blocks, each marker can be selected and replaced
 * through the same single-formula paste path that Notion already understands.
 */
function buildNotionPastePlan(input        , token = createPasteToken())                  {
  const formulas                       = [];
  const text = splitNotionPasteSegments(input)
    .map((segment) => {
      if (!segment.formula) {
        return segment.text;
      }

      const marker = `NLTX${token}X${formulas.length}X`;
      formulas.push({ marker, formula: segment.text });
      return marker;
    })
    .join("");

  return { text, formulas };
}

/** Maps a marker in concatenated DOM text back to its individual text nodes. */
function findMarkerTextSpan(
  chunks          ,
  marker        
)                             {
  if (!marker) {
    return undefined;
  }

  const markerStart = chunks.join("").indexOf(marker);
  if (markerStart === -1) {
    return undefined;
  }

  const start = locateChunkOffset(chunks, markerStart, true);
  const end = locateChunkOffset(chunks, markerStart + marker.length, false);
  if (!start || !end) {
    return undefined;
  }

  return {
    startChunk: start.chunk,
    startOffset: start.offset,
    endChunk: end.chunk,
    endOffset: end.offset
  };
}

function normalizeFormulaSource(value        )         {
  let text = value.trim();
  const delimiterPairs                          = [
    ["$$", "$$"],
    ["$", "$"],
    ["\\[", "\\]"],
    ["\\(", "\\)"]
  ];

  for (const [open, close] of delimiterPairs) {
    if (text.startsWith(open) && text.endsWith(close) && text.length >= open.length + close.length) {
      text = text.slice(open.length, text.length - close.length).trim();
      break;
    }
  }

  return text.replace(/\s+/g, "");
}

/** Splits normalized Markdown while leaving fenced and inline code untouched. */
function splitNotionPasteSegments(input        )                 {
  const segments                 = [];
  let textStart = 0;
  let index = 0;
  let inlineCodeMarker = "";
  let fenceMarker = "";
  let lineStart = true;

  while (index < input.length) {
    if (lineStart && !inlineCodeMarker) {
      const fence = readFence(input, index);
      if (fence) {
        if (!fenceMarker) {
          fenceMarker = fence;
        } else if (fence[0] === fenceMarker[0] && fence.length >= fenceMarker.length) {
          fenceMarker = "";
        }
        index += fence.length;
        lineStart = false;
        continue;
      }
    }

    if (!fenceMarker && input[index] === "`") {
      const marker = readRepeated(input, index, "`");
      if (!inlineCodeMarker) {
        inlineCodeMarker = marker;
      } else if (marker === inlineCodeMarker) {
        inlineCodeMarker = "";
      }
      index += marker.length;
      lineStart = false;
      continue;
    }

    if (!fenceMarker && !inlineCodeMarker && input.startsWith("$$", index)) {
      const end = findFormulaEnd(input, index + 2);
      if (end !== -1) {
        pushSegment(segments, input.slice(textStart, index), false);
        pushSegment(segments, input.slice(index, end + 2), true);
        index = end + 2;
        textStart = index;
        lineStart = false;
        continue;
      }
    }

    if (input[index] === "\n" || input[index] === "\r") {
      if (input[index] === "\r" && input[index + 1] === "\n") {
        index += 1;
      }
      lineStart = true;
    } else {
      lineStart = false;
    }
    index += 1;
  }

  pushSegment(segments, input.slice(textStart), false);
  return mergeAdjacentText(segments);
}

function readFence(input        , index        )                     {
  let cursor = index;
  let spaces = 0;
  while (input[cursor] === " " && spaces < 3) {
    cursor += 1;
    spaces += 1;
  }
  const character = input[cursor];
  if (character !== "`" && character !== "~") {
    return undefined;
  }
  const marker = readRepeated(input, cursor, character);
  return marker.length >= 3 ? marker : undefined;
}

function readRepeated(input        , index        , character        )         {
  let cursor = index;
  while (input[cursor] === character) {
    cursor += 1;
  }
  return input.slice(index, cursor);
}

function findFormulaEnd(input        , start        )         {
  for (let index = start; index < input.length - 1; index += 1) {
    if (input.startsWith("$$", index) && !isEscaped(input, index)) {
      return index;
    }
  }
  return -1;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function pushSegment(segments                , text        , formula         )       {
  if (text) {
    segments.push({ text, formula });
  }
}

function mergeAdjacentText(segments                )                 {
  const result                 = [];
  for (const segment of segments) {
    const previous = result[result.length - 1];
    if (previous && !previous.formula && !segment.formula) {
      previous.text += segment.text;
    } else {
      result.push({ ...segment });
    }
  }
  return result;
}

function createPasteToken()         {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `${timestamp}${random}`;
}

function locateChunkOffset(
  chunks          ,
  absoluteOffset        ,
  preferNextAtBoundary         
)                                                {
  let consumed = 0;
  for (let index = 0; index < chunks.length; index += 1) {
    const next = consumed + chunks[index].length;
    if (
      absoluteOffset < next ||
      (absoluteOffset === next && (!preferNextAtBoundary || index === chunks.length - 1))
    ) {
      return { chunk: index, offset: absoluteOffset - consumed };
    }
    consumed = next;
  }
  return undefined;
}



let redispatchingPaste = false;

document.documentElement.dataset.notionLatexPasteVersion = "0.6.3";

                                
                           
 

                                   
                     
                             
 

window.addEventListener(
  "paste",
  (event) => {
    if (redispatchingPaste || !event.clipboardData) {
      return;
    }

    const originalText = event.clipboardData.getData("text/plain");
    if (!originalText) {
      return;
    }

    const result = normalizeLatexForNotion(originalText);
    if (result.mathCount === 0) {
      return;
    }

    const target = getDispatchTarget(event);
    if (!target) {
      return;
    }

    event.preventDefault();
    event.stopImmediatePropagation();

    const plan = buildNotionPastePlan(result.text);
    void pasteWithFormulaPlaceholders(target, plan.text, plan.formulas);
  },
  true
);

function getDispatchTarget(event                )                 {
  const pathTarget = event.composedPath()[0];
  if (pathTarget instanceof Element) {
    return pathTarget;
  }
  return event.target instanceof Element ? event.target : document.activeElement;
}

function insertPlainTextFallback(text        )       {
  // execCommand keeps contenteditable frameworks in sync better than direct DOM mutation.
  document.execCommand("insertText", false, text);
}

async function pasteWithFormulaPlaceholders(
  initialTarget         ,
  placeholderText        ,
  formulas                      
)                {
  redispatchingPaste = true;
  let convertedCount = 0;
  const attemptedMarkers = new Set        ();
  try {
    dispatchPlainTextPaste(initialTarget, placeholderText);
    await waitForInitialPaste(formulas);

    for (const formula of formulas) {
      try {
        const target = await selectMarker(formula.marker);
        if (!target) {
          continue;
        }

        attemptedMarkers.add(formula.marker);
        const beforeFormulaPaste = getRenderedFormulaSnapshot();
        dispatchPlainTextPaste(target, formula.formula, { insertFallback: false });
        if (await waitForFormulaPasteResult(formula, beforeFormulaPaste)) {
          convertedCount += 1;
          // Notion removes the marker before its equation block has completely
          // settled. Starting the next replacement immediately can steal focus.
          await waitForEditorUpdate(140);
        }
      } catch (error) {
        console.warn("Notion LaTeX replacement failed", error);
        if (attemptedMarkers.has(formula.marker)) {
          await removeMarkerText(formula);
        } else {
          await replaceMarkerWithRawFormula(formula);
        }
      }
    }

    await cleanRemainingMarkers(formulas, attemptedMarkers);
    showConvertedToast(convertedCount, formulas.length);
  } finally {
    redispatchingPaste = false;
  }
}

async function waitForInitialPaste(formulas                      )                {
  const lastFormula = formulas[formulas.length - 1];
  if (!lastFormula) {
    return;
  }

  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    // Notion creates pasted blocks in document order. Seeing the last marker
    // means it has finished materializing the response before replacements
    // start changing focus and block types.
    if (findMarker(lastFormula.marker)) {
      await waitForEditorUpdate(120);
      return;
    }
    await waitForEditorUpdate(25);
  }
}

function dispatchPlainTextPaste(
  target         ,
  text        ,
  options                       = {}
)       {
  const clipboardData = new DataTransfer();
  clipboardData.setData("text/plain", text);
  const replacementEvent = new ClipboardEvent("paste", {
    bubbles: true,
    cancelable: true,
    composed: true,
    clipboardData
  });

  const notCancelled = target.dispatchEvent(replacementEvent);
  if (notCancelled && options.insertFallback !== false) {
    insertPlainTextFallback(text);
  }
}

async function selectMarker(marker        )                                   {
  const deadline = Date.now() + 2500;
  while (Date.now() < deadline) {
    const match = findMarker(marker);
    if (match) {
      match.editable.focus({ preventScroll: true });
      const selection = document.getSelection();
      if (!selection) {
        return undefined;
      }
      selection.removeAllRanges();
      selection.addRange(match.range);
      return match.editable;
    }

    await waitForEditorUpdate(25);
  }

  return undefined;
}

function findMarker(marker        )                                                      {
  const editables = document.querySelectorAll             ('[contenteditable="true"]');
  for (const editable of editables) {
    const nodes = collectOwnedTextNodes(editable);
    const span = findMarkerTextSpan(nodes.map((node) => node.data), marker);
    if (!span) {
      continue;
    }

    const range = document.createRange();
    range.setStart(nodes[span.startChunk], span.startOffset);
    range.setEnd(nodes[span.endChunk], span.endOffset);
    return { editable, range };
  }
  return undefined;
}

function collectOwnedTextNodes(editable             )         {
  const nodes         = [];
  const walker = document.createTreeWalker(editable, NodeFilter.SHOW_TEXT);
  let current = walker.nextNode();
  while (current) {
    if (
      current instanceof Text &&
      current.data.length > 0 &&
      current.parentElement?.closest('[contenteditable="true"]') === editable
    ) {
      nodes.push(current);
    }
    current = walker.nextNode();
  }
  return nodes;
}

async function waitForFormulaPasteResult(
  formula                    ,
  beforeFormulaPaste                         
)                   {
  const deadline = Date.now() + 2200;
  while (Date.now() < deadline) {
    if (!findMarker(formula.marker)) {
      return true;
    }

    if (hasRenderedFormula(formula.formula, beforeFormulaPaste)) {
      await removeMarkerText(formula);
      return true;
    }

    await waitForEditorUpdate(20);
  }

  // Notion can insert the equation block but leave the selected placeholder
  // behind. Replacing that leftover marker with raw "$$...$$" duplicates the
  // formula, so clean the marker after a replacement paste has been attempted.
  if (hasRenderedFormula(formula.formula, beforeFormulaPaste)) {
    await removeMarkerText(formula);
    return true;
  }

  await replaceMarkerWithRawFormula(formula);
  return false;
}

async function replaceMarkerWithRawFormula(formula                    )                {
  const target = await selectMarker(formula.marker);
  if (target) {
    document.execCommand("insertText", false, formula.formula);
    await waitForEditorUpdate(40);
  }
}

async function removeMarkerText(formula                    )                   {
  const target = await selectMarker(formula.marker);
  if (!target) {
    return false;
  }

  document.execCommand("delete", false);
  await waitForEditorUpdate(40);
  return !findMarker(formula.marker);
}

async function cleanRemainingMarkers(
  formulas                      ,
  attemptedMarkers             
)                {
  for (const formula of formulas) {
    if (!findMarker(formula.marker)) {
      continue;
    }

    if (attemptedMarkers.has(formula.marker)) {
      await removeMarkerText(formula);
    } else {
      await replaceMarkerWithRawFormula(formula);
    }
  }
}

function getRenderedFormulaSnapshot()                          {
  return {
    katexCount: document.querySelectorAll(".katex").length,
    texAnnotationCount: getTexAnnotations().length
  };
}

function hasRenderedFormula(
  formula        ,
  beforeFormulaPaste                         
)          {
  const current = getRenderedFormulaSnapshot();
  if (
    current.katexCount > beforeFormulaPaste.katexCount ||
    current.texAnnotationCount > beforeFormulaPaste.texAnnotationCount
  ) {
    return true;
  }

  const expected = normalizeFormulaSource(formula);
  if (!expected) {
    return false;
  }

  for (const annotation of getTexAnnotations()) {
    if (normalizeFormulaSource(annotation.textContent ?? "") === expected) {
      return true;
    }
  }

  return false;
}

function getTexAnnotations()            {
  return Array.from(document.querySelectorAll("annotation")).filter((annotation) => {
    const encoding = annotation.getAttribute("encoding") ?? "";
    return encoding.toLowerCase().includes("application/x-tex");
  });
}

function waitForEditorUpdate(delay        )                {
  return new Promise((resolve) => window.setTimeout(resolve, delay));
}

function showConvertedToast(convertedCount        , mathCount        )       {
  const existing = document.getElementById("notion-latex-paste-toast");
  existing?.remove();

  const toast = document.createElement("div");
  toast.id = "notion-latex-paste-toast";
  const complete = convertedCount === mathCount;
  toast.textContent = complete
    ? `已转换 ${mathCount} 个 LaTeX 公式`
    : `已转换 ${convertedCount}/${mathCount} 个公式，未转换的已保留原文`;
  Object.assign(toast.style, {
    position: "fixed",
    right: "20px",
    bottom: "20px",
    zIndex: "2147483647",
    padding: "9px 12px",
    borderRadius: "7px",
    background: complete ? "#238636" : "#b45309",
    color: "white",
    font: "13px -apple-system, BlinkMacSystemFont, sans-serif",
    boxShadow: "0 4px 18px rgba(0, 0, 0, 0.22)",
    pointerEvents: "none"
  });
  document.documentElement.appendChild(toast);
  window.setTimeout(() => toast.remove(), 1800);
}

})();
