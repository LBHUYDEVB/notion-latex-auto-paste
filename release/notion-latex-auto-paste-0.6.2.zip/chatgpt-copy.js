(() => {
                                  
               
                   
                    
 

                         
               
                    
 

                     
               
                
                     
                      
                   
 

const DELIMITERS              = [
  { open: "$$", close: "$$", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\[", close: "\\]", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\(", close: "\\)", outputOpen: "$$", outputClose: "$$", display: false },
  { open: "$", close: "$", outputOpen: "$$", outputClose: "$$", display: false }
];

/**
 * Makes copied LaTeX compatible with Notion without changing surrounding prose.
 * Fenced and inline code are intentionally opaque.
 */
function normalizeLatexForNotion(input        )                  {
  const segments = splitFencedCode(input);
  let mathCount = 0;

  const text = segments
    .map((segment) => {
      if (segment.code) {
        return segment.text;
      }

      const result = normalizeTextSegment(segment.text);
      mathCount += result.mathCount;
      return result.text;
    })
    .join("");

  return {
    text,
    changed: text !== input,
    mathCount
  };
}

function splitFencedCode(input        )                                         {
  const lines = input.match(/[^\r\n]*(?:\r\n|\n|\r|$)/g)?.filter(Boolean) ?? [];
  const segments                                         = [];
  let buffer = "";
  let inFence = false;
  let fenceCharacter = "";
  let fenceLength = 0;

  const flush = (code         ) => {
    if (buffer) {
      segments.push({ text: buffer, code });
      buffer = "";
    }
  };

  for (const line of lines) {
    let openedThisLine = false;
    if (!inFence) {
      const opening = line.match(/^ {0,3}(`{3,}|~{3,})/);
      if (opening) {
        flush(false);
        inFence = true;
        openedThisLine = true;
        fenceCharacter = opening[1][0];
        fenceLength = opening[1].length;
      }
    }

    buffer += line;

    if (inFence && !openedThisLine) {
      const closingPattern = new RegExp(`^ {0,3}${escapeRegExp(fenceCharacter)}{${fenceLength},}\\s*$`);
      if (closingPattern.test(line.replace(/(?:\r\n|\n|\r)$/, ""))) {
        flush(true);
        inFence = false;
        fenceCharacter = "";
        fenceLength = 0;
      }
    }
  }

  flush(inFence);
  return segments;
}

function normalizeTextSegment(input        )                {
  let output = "";
  let mathCount = 0;
  let index = 0;

  while (index < input.length) {
    if (input[index] === "`") {
      const codeEnd = findInlineCodeEnd(input, index);
      if (codeEnd !== -1) {
        output += input.slice(index, codeEnd);
        index = codeEnd;
        continue;
      }
    }

    const delimiter = delimiterAt(input, index);
    if (!delimiter || !isValidOpening(input, index, delimiter)) {
      output += input[index];
      index += 1;
      continue;
    }

    const bodyStart = index + delimiter.open.length;
    const closingIndex = findClosingDelimiter(input, bodyStart, delimiter);
    if (closingIndex === -1) {
      output += input[index];
      index += 1;
      continue;
    }

    const body = input.slice(bodyStart, closingIndex);
    if (!isValidMathBody(body)) {
      output += input[index];
      index += 1;
      continue;
    }

    const normalizedBody = collapsePhysicalLineBreaks(body);
    output += `${delimiter.outputOpen}${normalizedBody}${delimiter.outputClose}`;
    mathCount += 1;
    index = closingIndex + delimiter.close.length;
  }

  return { text: output, mathCount };
}

function delimiterAt(input        , index        )                        {
  if (isEscaped(input, index)) {
    return undefined;
  }

  return DELIMITERS.find((delimiter) => input.startsWith(delimiter.open, index));
}

function isValidOpening(input        , index        , delimiter           )          {
  if (delimiter.open !== "$") {
    return true;
  }

  const previous = input[index - 1] ?? "";
  const next = input[index + 1] ?? "";
  return !/[A-Za-z0-9\\]/.test(previous) && next !== "$" && !/\s/.test(next);
}

function findClosingDelimiter(input        , start        , delimiter           )         {
  for (let index = start; index <= input.length - delimiter.close.length; index += 1) {
    if (!input.startsWith(delimiter.close, index) || isEscaped(input, index)) {
      continue;
    }

    if (delimiter.close === "$" && input[index + 1] === "$") {
      continue;
    }

    if (delimiter.close === "$") {
      const previous = input[index - 1] ?? "";
      const next = input[index + 1] ?? "";
      if (/\s/.test(previous) || /[0-9]/.test(next)) {
        continue;
      }
    }

    return index;
  }

  return -1;
}

function isValidMathBody(body        )          {
  const trimmed = body.trim();
  return trimmed.length > 0 && !/(?:\r\n|\n|\r)[ \t]*(?:\r\n|\n|\r)/.test(trimmed);
}

function collapsePhysicalLineBreaks(body        )         {
  return body.replace(/[ \t]*(?:\r\n|\n|\r)[ \t]*/g, " ").trim();
}

function findInlineCodeEnd(input        , start        )         {
  let markerLength = 1;
  while (input[start + markerLength] === "`") {
    markerLength += 1;
  }

  const marker = "`".repeat(markerLength);
  const end = input.indexOf(marker, start + markerLength);
  return end === -1 ? -1 : end + markerLength;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function escapeRegExp(value        )         {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}


const clipboardPrototype = globalThis.Clipboard?.prototype;

if (clipboardPrototype) {
  patchWriteText(clipboardPrototype);
  patchWrite(clipboardPrototype);
  document.documentElement.dataset.notionLatexCopyVersion = "0.6.2";
}

function patchWriteText(prototype           )       {
  const original = prototype.writeText;
  if (typeof original !== "function" || original.name === "notionLatexWriteText") {
    return;
  }

  Object.defineProperty(prototype, "writeText", {
    configurable: true,
    writable: true,
    value: async function notionLatexWriteText(                 text        )                {
      const result = normalizeLatexForNotion(text);
      const output = result.changed && result.mathCount > 0 ? result.text : text;
      await original.call(this, output);
      if (output !== text) {
        showCopyToast(result.mathCount);
      }
    }
  });
}

function patchWrite(prototype           )       {
  const original = prototype.write;
  if (typeof original !== "function" || original.name === "notionLatexWrite") {
    return;
  }

  Object.defineProperty(prototype, "write", {
    configurable: true,
    writable: true,
    value: async function notionLatexWrite(                 items                 )                {
      const convertedItems = await Promise.all(items.map(convertClipboardItem));
      return original.call(this, convertedItems);
    }
  });
}

async function convertClipboardItem(item               )                         {
  if (!item.types.includes("text/plain")) {
    return item;
  }

  const plainBlob = await item.getType("text/plain");
  const plainText = await plainBlob.text();
  const result = normalizeLatexForNotion(plainText);
  if (!result.changed || result.mathCount === 0) {
    return item;
  }

  const entries                       = {};
  for (const type of item.types) {
    if (type === "text/plain") {
      entries[type] = new Blob([result.text], { type });
    } else {
      entries[type] = await item.getType(type);
    }
  }

  showCopyToast(result.mathCount);
  return new ClipboardItem(entries, { presentationStyle: item.presentationStyle });
}

function showCopyToast(mathCount        )       {
  const existing = document.getElementById("notion-latex-copy-toast");
  existing?.remove();

  const toast = document.createElement("div");
  toast.id = "notion-latex-copy-toast";
  toast.textContent = `已整理 ${mathCount} 个公式，可直接粘贴到 Notion`;
  Object.assign(toast.style, {
    position: "fixed",
    right: "20px",
    bottom: "76px",
    zIndex: "2147483647",
    padding: "9px 12px",
    borderRadius: "7px",
    background: "#238636",
    color: "white",
    font: "13px -apple-system, BlinkMacSystemFont, sans-serif",
    boxShadow: "0 4px 18px rgba(0, 0, 0, 0.22)",
    pointerEvents: "none"
  });
  document.documentElement.appendChild(toast);
  window.setTimeout(() => toast.remove(), 2200);
}

})();
