(() => {
                                  
               
                   
                    
 

                         
               
                    
 

                     
               
                
                     
                      
                   
 

                                
               
              
 

const DELIMITERS              = [
  { open: "$$", close: "$$", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\[", close: "\\]", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\(", close: "\\)", outputOpen: "$$", outputClose: "$$", display: false },
  { open: "$", close: "$", outputOpen: "$$", outputClose: "$$", display: false }
];

const STRUCTURED_LINE_BREAK_ENVIRONMENTS = new Set([
  "align",
  "align*",
  "aligned",
  "alignedat",
  "alignedat*",
  "array",
  "bmatrix",
  "Bmatrix",
  "cases",
  "dcases",
  "gather",
  "gather*",
  "gathered",
  "matrix",
  "multline",
  "multline*",
  "pmatrix",
  "rcases",
  "smallmatrix",
  "split",
  "subarray",
  "vmatrix",
  "Vmatrix"
]);

/**
 * Makes copied LaTeX compatible with Notion without changing surrounding prose.
 * Fenced and inline code are intentionally opaque.
 */
function normalizeLatexForNotion(input        )                  {
  const segments = splitFencedCode(input);
  let mathCount = 0;

  const text = segments
    .map((segment) => {
      if (segment.code) {
        return segment.text;
      }

      const repaired = repairCorruptedMathMarkdown(segment.text);
      const result = normalizeTextSegment(repaired);
      mathCount += result.mathCount;
      return result.text;
    })
    .join("");

  return {
    text,
    changed: text !== input,
    mathCount
  };
}

function splitFencedCode(input        )                                         {
  const lines = input.match(/[^\r\n]*(?:\r\n|\n|\r|$)/g)?.filter(Boolean) ?? [];
  const segments                                         = [];
  let buffer = "";
  let inFence = false;
  let fenceCharacter = "";
  let fenceLength = 0;

  const flush = (code         ) => {
    if (buffer) {
      segments.push({ text: buffer, code });
      buffer = "";
    }
  };

  for (const line of lines) {
    let openedThisLine = false;
    if (!inFence) {
      const opening = line.match(/^ {0,3}(`{3,}|~{3,})/);
      if (opening) {
        flush(false);
        inFence = true;
        openedThisLine = true;
        fenceCharacter = opening[1][0];
        fenceLength = opening[1].length;
      }
    }

    buffer += line;

    if (inFence && !openedThisLine) {
      const closingPattern = new RegExp(`^ {0,3}${escapeRegExp(fenceCharacter)}{${fenceLength},}\\s*$`);
      if (closingPattern.test(line.replace(/(?:\r\n|\n|\r)$/, ""))) {
        flush(true);
        inFence = false;
        fenceCharacter = "";
        fenceLength = 0;
      }
    }
  }

  flush(inFence);
  return segments;
}

function normalizeTextSegment(input        )                {
  let output = "";
  let mathCount = 0;
  let index = 0;

  while (index < input.length) {
    const bareBracketBlock = readBareBracketMathBlock(input, index);
    if (bareBracketBlock) {
      output += `$$${normalizeMathBody(bareBracketBlock.body, true)}$$`;
      mathCount += 1;
      index = bareBracketBlock.end;
      continue;
    }

    if (input[index] === "`") {
      const codeEnd = findInlineCodeEnd(input, index);
      if (codeEnd !== -1) {
        output += input.slice(index, codeEnd);
        index = codeEnd;
        continue;
      }
    }

    const delimiter = delimiterAt(input, index);
    if (!delimiter || !isValidOpening(input, index, delimiter)) {
      output += input[index];
      index += 1;
      continue;
    }

    const bodyStart = index + delimiter.open.length;
    const closingIndex = findClosingDelimiter(input, bodyStart, delimiter);
    if (closingIndex === -1) {
      output += input[index];
      index += 1;
      continue;
    }

    const body = input.slice(bodyStart, closingIndex);
    if (!isValidMathBody(body, delimiter.display)) {
      output += input[index];
      index += 1;
      continue;
    }

    const normalizedBody = normalizeMathBody(body, delimiter.display);
    output += `${delimiter.outputOpen}${normalizedBody}${delimiter.outputClose}`;
    mathCount += 1;
    index = closingIndex + delimiter.close.length;
  }

  return { text: output, mathCount };
}

function repairCorruptedMathMarkdown(input        )         {
  const proseUnwrapped = input.replace(/\$\$([^$\r\n]+)\$\$/g, (match, body        ) =>
    isPlainCjkProse(body) ? body.trim() : match
  );
  return repairDetachedSetextEquations(proseUnwrapped);
}

function isPlainCjkProse(body        )          {
  const trimmed = body.trim();
  return (
    /[\p{Script=Han}]/u.test(trimmed) &&
    !/[\\A-Za-z0-9_^=+\-*/<>{}[\]]/.test(trimmed)
  );
}

function repairDetachedSetextEquations(input        )         {
  const newline = input.match(/\r\n|\n|\r/)?.[0] ?? "\n";
  const lines = input.split(/\r\n|\n|\r/);

  for (let index = 0; index < lines.length; index += 1) {
    if (!/^[ \t]*={3,}[ \t]*$/.test(lines[index])) {
      continue;
    }

    const leftIndex = findNonEmptyLine(lines, index - 1, -1);
    const rightIndex = findNonEmptyLine(lines, index + 1, 1);
    if (leftIndex === -1 || rightIndex === -1) {
      continue;
    }

    const left = stripDisplayDelimiters(lines[leftIndex]);
    const firstRight = stripDisplayDelimiters(lines[rightIndex]);
    if (!looksLikeLatex(left) && !looksLikeLatex(firstRight)) {
      continue;
    }

    let start = leftIndex;
    if (leftIndex > 0 && lines[leftIndex - 1].trim() === "$$") {
      start = leftIndex - 1;
    }

    const end = findCorruptedFormulaEnd(lines, rightIndex);
    if (end === -1) {
      continue;
    }

    const right = lines
      .slice(rightIndex, end + 1)
      .map(stripDisplayDelimiters)
      .filter((line) => line.trim().length > 0)
      .join("\n");
    const formula = normalizeMathBody(`${left}\n=\n${right}`, true);
    lines.splice(start, end - start + 1, `$$${formula}$$`);
    index = start;
  }

  return lines.join(newline);
}

function findNonEmptyLine(
  lines          ,
  start        ,
  direction        
)         {
  for (let index = start; index >= 0 && index < lines.length; index += direction) {
    if (lines[index].trim()) {
      return index;
    }
  }
  return -1;
}

function findCorruptedFormulaEnd(lines          , rightIndex        )         {
  for (let index = rightIndex; index < lines.length; index += 1) {
    const trimmed = lines[index].trim();
    if (trimmed.includes("$$")) {
      return index;
    }
    if (index > rightIndex && !trimmed) {
      const next = findNonEmptyLine(lines, index + 1, 1);
      if (next === -1 || !looksLikeLatex(stripDisplayDelimiters(lines[next]))) {
        return -1;
      }
    }
  }
  return -1;
}

function stripDisplayDelimiters(value        )         {
  return value.replace(/^\s*\$\$|\$\$\s*$/g, "").trim();
}

function looksLikeLatex(value        )          {
  return /\\[A-Za-z]+|[_^{}]|[∫∑√∞≤≥≠≈]/.test(value);
}

function readBareBracketMathBlock(
  input        ,
  index        
)                                   {
  if (
    input[index] !== "[" ||
    (index > 0 && input[index - 1] !== "\n" && input[index - 1] !== "\r")
  ) {
    return undefined;
  }

  const match = input
    .slice(index)
    .match(/^\[[ \t]*(?:\r\n|\n|\r)([\s\S]*?)(?:\r\n|\n|\r)[ \t]*\](?=[ \t]*(?:\r\n|\n|\r|$))/);
  if (!match || !isLikelyBareBracketMath(match[1])) {
    return undefined;
  }

  return {
    body: match[1],
    end: index + match[0].length
  };
}

function isLikelyBareBracketMath(body        )          {
  if (!isValidMathBody(body, true)) {
    return false;
  }

  const trimmed = body.trim();
  return (
    /\\[A-Za-z]+/.test(trimmed) ||
    /[_^=]/.test(trimmed) ||
    /[∫∑√∞≤≥≠≈→←]/.test(trimmed)
  );
}

function delimiterAt(input        , index        )                        {
  if (isEscaped(input, index)) {
    return undefined;
  }

  return DELIMITERS.find((delimiter) => input.startsWith(delimiter.open, index));
}

function isValidOpening(input        , index        , delimiter           )          {
  if (delimiter.open !== "$") {
    return true;
  }

  const previous = input[index - 1] ?? "";
  const next = input[index + 1] ?? "";
  return !/[A-Za-z0-9\\]/.test(previous) && next !== "$" && !/\s/.test(next);
}

function findClosingDelimiter(input        , start        , delimiter           )         {
  for (let index = start; index <= input.length - delimiter.close.length; index += 1) {
    if (!input.startsWith(delimiter.close, index) || isEscaped(input, index)) {
      continue;
    }

    if (
      delimiter.close === "$$" &&
      hasUnclosedStructuredEnvironment(input.slice(start, index))
    ) {
      continue;
    }

    if (delimiter.close === "$" && input[index + 1] === "$") {
      continue;
    }

    if (delimiter.close === "$") {
      const previous = input[index - 1] ?? "";
      const next = input[index + 1] ?? "";
      if (/\s/.test(previous) || /[0-9]/.test(next)) {
        continue;
      }
    }

    return index;
  }

  return -1;
}

function isValidMathBody(body        , allowBlankLines = false)          {
  const trimmed = body.trim();
  const normalizedLineEndings = trimmed.replace(/\r\n?|\u2028|\u2029/g, "\n");
  return trimmed.length > 0 && (allowBlankLines || !/\n[ \t]*\n/.test(normalizedLineEndings));
}

function normalizeMathBody(body        , display         )         {
  const repaired = display ? repairDisplayClipboardArtifacts(body) : body;
  const structured = repairStructuredEnvironmentLineBreaks(repaired);
  const collapsed = normalizeRowBreakArtifacts(collapsePhysicalLineBreaks(structured));
  return display
    ? collapsed.replace(/(^|[ \t])=(?:[ \t]+=)+(?=[ \t]|$)/g, "$1=")
    : collapsed;
}

function repairDisplayClipboardArtifacts(body        )         {
  return body
    .replace(/\r\n?|\u2028|\u2029/g, "\n")
    .replace(/[ \t]*\$\$(?=\\end\{[A-Za-z*]+\})/g, " ")
    .replace(/^[ \t]*={3,}[ \t]*$/gm, "=")
    .replace(/^[ \t]*#{1,6}[ \t]+(?=\\)/gm, "= ")
    .replace(/(^|[ \t])={2,}(?=[ \t]|$)/g, "$1=");
}

function hasUnclosedStructuredEnvironment(body        )          {
  const stack           = [];
  const pattern = /\\(begin|end)\{([^}]+)\}/g;
  let match                        ;
  while ((match = pattern.exec(body))) {
    const [, kind, environment] = match;
    if (!STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(environment)) {
      continue;
    }

    if (kind === "begin") {
      stack.push(environment);
      continue;
    }

    const lastIndex = stack.lastIndexOf(environment);
    if (lastIndex !== -1) {
      stack.splice(lastIndex, 1);
    }
  }

  return stack.length > 0;
}

function collapsePhysicalLineBreaks(body        )         {
  return body
    .replace(/\r\n?|\u2028|\u2029/g, "\n")
    .replace(/[ \t]*\n+[ \t]*/g, " ")
    .replace(/(^|[ \t])={3,}(?=[ \t]|$)/g, "$1=")
    .trim();
}

function repairStructuredEnvironmentLineBreaks(body        )         {
  const normalized = body.replace(/\r\n?|\u2028|\u2029/g, "\n");
  if (!/\\(?:begin|end)\{/.test(normalized)) {
    return normalized;
  }

  const lines = normalized.split("\n");
  const environmentStack           = [];
  return lines
    .map((line, index) => {
      const trimmed = line.trim();
      const insideBefore = environmentStack.length > 0;
      updateStructuredEnvironmentStack(environmentStack, trimmed);
      const insideAfter = environmentStack.length > 0;

      if (
        !trimmed ||
        (!insideBefore && !insideAfter) ||
        isOnlyStructuredEnvironmentBoundary(trimmed) ||
        !hasFollowingStructuredEnvironmentRow(lines, index + 1)
      ) {
        return line;
      }

      if (hasTrailingSingleBackslash(trimmed)) {
        return `${line.trimEnd()}\\`;
      }

      if (hasExplicitLatexLineBreak(trimmed)) {
        return line;
      }

      return `${line.trimEnd()} \\\\`;
    })
    .join("\n");
}

function updateStructuredEnvironmentStack(stack          , line        )       {
  const pattern = /\\(begin|end)\{([^}]+)\}/g;
  let match                        ;
  while ((match = pattern.exec(line))) {
    const [, kind, environment] = match;
    if (!STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(environment)) {
      continue;
    }

    if (kind === "begin") {
      stack.push(environment);
    } else {
      const lastIndex = stack.lastIndexOf(environment);
      if (lastIndex !== -1) {
        stack.splice(lastIndex, 1);
      }
    }
  }
}

function isOnlyStructuredEnvironmentBoundary(line        )          {
  const match = line.match(/^\\(?:begin|end)\{([^}]+)\}$/);
  return !!match && STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(match[1]);
}

function hasExplicitLatexLineBreak(line        )          {
  return /\\\\(?:\[[^\]]*\])?\s*$|\\cr\s*$/.test(line);
}

function hasTrailingSingleBackslash(line        )          {
  const match = line.match(/\\+$/);
  return match?.[0].length === 1;
}

function normalizeRowBreakArtifacts(body        )         {
  return body.replace(/\\[ \t]+\\\\/g, "\\\\");
}

function hasFollowingStructuredEnvironmentRow(lines          , start        )          {
  for (let index = start; index < lines.length; index += 1) {
    const trimmed = lines[index].trim();
    if (!trimmed) {
      continue;
    }
    return !/^\\end\{([^}]+)\}$/.test(trimmed);
  }
  return false;
}

function findInlineCodeEnd(input        , start        )         {
  let markerLength = 1;
  while (input[start + markerLength] === "`") {
    markerLength += 1;
  }

  const marker = "`".repeat(markerLength);
  const end = input.indexOf(marker, start + markerLength);
  return end === -1 ? -1 : end + markerLength;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function escapeRegExp(value        )         {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}


const clipboardPrototype = globalThis.Clipboard?.prototype;
const originalClipboardWriteText = clipboardPrototype?.writeText;
const originalClipboardWrite = clipboardPrototype?.write;

if (clipboardPrototype) {
  patchWriteText(clipboardPrototype);
  patchWrite(clipboardPrototype);
}
installResponseCopyHandler();
document.documentElement.dataset.notionLatexCopyVersion = "0.6.14";

                              
               
                    
 

function patchWriteText(prototype           )       {
  const original = prototype.writeText;
  if (typeof original !== "function" || original.name === "notionLatexWriteText") {
    return;
  }

  Object.defineProperty(prototype, "writeText", {
    configurable: true,
    writable: true,
    value: async function notionLatexWriteText(                 text        )                {
      const result = normalizeLatexForNotion(text);
      const output = result.changed && result.mathCount > 0 ? result.text : text;
      await original.call(this, output);
      if (output !== text) {
        showCopyToast(result.mathCount);
      }
    }
  });
}

function patchWrite(prototype           )       {
  const original = prototype.write;
  if (typeof original !== "function" || original.name === "notionLatexWrite") {
    return;
  }

  Object.defineProperty(prototype, "write", {
    configurable: true,
    writable: true,
    value: async function notionLatexWrite(                 items                 )                {
      const convertedItems = await Promise.all(items.map(convertClipboardItem));
      return original.call(this, convertedItems);
    }
  });
}

async function convertClipboardItem(item               )                         {
  if (!item.types.includes("text/plain")) {
    return item;
  }

  const plainBlob = await item.getType("text/plain");
  const plainText = await plainBlob.text();
  const result = normalizeLatexForNotion(plainText);
  if (!result.changed || result.mathCount === 0) {
    return item;
  }

  const entries                       = {};
  for (const type of item.types) {
    if (type === "text/plain") {
      entries[type] = new Blob([result.text], { type });
    } else {
      entries[type] = await item.getType(type);
    }
  }

  showCopyToast(result.mathCount);
  return new ClipboardItem(entries, { presentationStyle: item.presentationStyle });
}

function showCopyToast(mathCount        , imageCount = 0)       {
  const existing = document.getElementById("notion-latex-copy-toast");
  existing?.remove();

  const toast = document.createElement("div");
  toast.id = "notion-latex-copy-toast";
  const summary = [
    mathCount > 0 ? `整理 ${mathCount} 个公式` : "",
    imageCount > 0 ? `复制 ${imageCount} 张图片` : ""
  ].filter(Boolean).join("并");
  toast.textContent = `已${summary}，可粘贴到 Notion`;
  Object.assign(toast.style, {
    position: "fixed",
    right: "20px",
    bottom: "76px",
    zIndex: "2147483647",
    padding: "9px 12px",
    borderRadius: "7px",
    background: "#238636",
    color: "white",
    font: "13px -apple-system, BlinkMacSystemFont, sans-serif",
    boxShadow: "0 4px 18px rgba(0, 0, 0, 0.22)",
    pointerEvents: "none"
  });
  document.documentElement.appendChild(toast);
  window.setTimeout(() => toast.remove(), 2200);
}

function installResponseCopyHandler()       {
  document.addEventListener(
    "click",
    (event) => {
      const target = event.target;
      const button = target instanceof Element ? target.closest('button, [role="button"]') : null;
      if (!button || !isResponseCopyButton(button)) {
        return;
      }

      const markdownRoot = findResponseMarkdown(button);
      if (!markdownRoot) {
        return;
      }

      const serialized = serializeResponse(markdownRoot);
      if ((serialized.mathCount === 0 && serialized.imageCount === 0) || !serialized.text) {
        return;
      }

      event.preventDefault();
      event.stopImmediatePropagation();
      void writeSerializedResponse(serialized);
    },
    true
  );
}

function isResponseCopyButton(button                   )          {
  if (button.closest(".katex, .katex-display, mjx-container, pre")) {
    return false;
  }

  const copyIntent = hasCopyIntent(button);
  if (!copyIntent) {
    return false;
  }

  return Boolean(
    button.closest(
      'article, [data-message-author-role="assistant"], [data-testid*="conversation-turn" i], [data-testid*="message" i]'
    ) ?? findBestResponseFallbackRoot(button, null, null)
  );
}

function hasCopyIntent(button                   )          {
  const labels = [
    button.getAttribute("aria-label"),
    button.getAttribute("title"),
    button.textContent
  ]
    .filter(Boolean)
    .map((value) => value .trim().toLowerCase());
  const testId = button.getAttribute("data-testid")?.toLowerCase() ?? "";

  return (
    labels.some((label) =>
      /^(?:copy(?: response| answer| message| turn)?|复制(?:回复|回答|消息|本次输出)?)$/i.test(label)
    ) || /copy[-_](?:turn|response|message)/.test(testId)
  );
}

function findResponseMarkdown(button                   )                     {
  const article = button.closest             ("article");
  const assistant = button.closest             ('[data-message-author-role="assistant"]');
  const turn = button.closest             ('[data-testid*="conversation-turn" i]');
  const message = button.closest             ('[data-testid*="message" i]');
  const markdownRoot =
    article?.querySelector             ('[data-message-author-role="assistant"] .markdown') ??
    article?.querySelector             (".markdown") ??
    assistant?.querySelector             (".markdown") ??
    turn?.querySelector             (".markdown") ??
    message?.querySelector             (".markdown") ??
    null;

  if (markdownRoot) {
    const responseContainer = assistant ?? article ?? turn ?? message;
    if (
      responseContainer?.querySelector("img") &&
      !markdownRoot.querySelector("img")
    ) {
      return responseContainer;
    }
    return markdownRoot;
  }

  return findBestResponseFallbackRoot(button, assistant, article);
}

function findBestResponseFallbackRoot(
  button                   ,
  assistant                    ,
  article                    
)                     {
  const candidates                = [
    assistant,
    article,
    button.closest             ('[data-testid*="conversation-turn" i]'),
    button.closest             ('[data-testid*="message" i]')
  ].filter((candidate)                           => !!candidate);

  for (
    let current = button.parentElement;
    current && current !== document.body && current !== document.documentElement;
    current = current.parentElement
  ) {
    if (!candidates.includes(current)) {
      candidates.push(current);
    }
    if (candidates.length >= 16) {
      break;
    }
  }

  return (
    candidates
      .filter(looksLikeResponseWithMath)
      .sort((left, right) => (left.textContent?.length ?? 0) - (right.textContent?.length ?? 0))[0] ??
    null
  );
}

function looksLikeResponseWithMath(candidate             )          {
  const text = candidate.textContent ?? "";
  return (
    text.length > 40 &&
    (Boolean(candidate.querySelector(".katex, .katex-display, mjx-container, math, annotation")) ||
      /\\begin\{|\\end\{|\\mathbf|\\text|Y_|D\^\{/.test(text))
  );
}

async function writeSerializedResponse(serialized                    )                {
  try {
    if (originalClipboardWrite && navigator.clipboard && typeof ClipboardItem === "function") {
      const clipboardItem = new ClipboardItem({
        "text/plain": new Blob([serialized.text], { type: "text/plain" }),
        "text/html": new Blob([wrapClipboardHtml(serialized.html)], { type: "text/html" })
      });
      await originalClipboardWrite.call(navigator.clipboard, [clipboardItem]);
    } else if (!copyRichTextWithSelection(wrapClipboardHtml(serialized.html))) {
      throw new Error("Clipboard API is unavailable");
    }
    showCopyToast(serialized.mathCount, serialized.imageCount);
  } catch (error) {
    console.warn("Notion LaTeX response copy failed", error);
    if (!copyRichTextWithSelection(wrapClipboardHtml(serialized.html))) {
      copyTextWithSelection(serialized.text);
    }
  }
}

function wrapClipboardHtml(html        )       {
  return `<!doctype html><html><body><!--StartFragment-->${html}<!--EndFragment--></body></html>`;
}

function copyRichTextWithSelection(html        )          {
  const container = document.createElement("div");
  container.contentEditable = "true";
  container.innerHTML = html;
  Object.assign(container.style, {
    position: "fixed",
    left: "-10000px",
    top: "0",
    width: "max-content"
  });

  const selection = document.getSelection();
  const previousRanges = [];
  if (selection) {
    for (let index = 0; index < selection.rangeCount; index += 1) {
      previousRanges.push(selection.getRangeAt(index).cloneRange());
    }
  }

  document.body.appendChild(container);
  container.focus({ preventScroll: true });
  if (selection) {
    const range = document.createRange();
    range.selectNodeContents(container);
    selection.removeAllRanges();
    selection.addRange(range);
  }
  const copied = document.execCommand("copy");
  selection?.removeAllRanges();
  for (const range of previousRanges) {
    selection?.addRange(range);
  }
  container.remove();
  return copied;
}

function copyTextWithSelection(text        )          {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  Object.assign(textarea.style, {
    position: "fixed",
    left: "-9999px",
    top: "0"
  });
  document.body.appendChild(textarea);
  textarea.select();
  const copied = document.execCommand("copy");
  textarea.remove();
  return copied;
}

function serializeResponse(root             )                     {
  const state = { mathCount: 0, imageCount: 0 };
  const serialized = serializeChildren(root, state)
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  const normalized = normalizeLatexForNotion(serialized);
  return {
    text: normalized.text,
    html: serializeResponseHtml(root),
    mathCount: Math.max(state.mathCount, normalized.mathCount),
    imageCount: state.imageCount
  };
}

function serializeResponseHtml(root             )       {
  const clone = root.cloneNode(true);

  const replaceMath = (node      ) => {
    if (!(node instanceof HTMLElement)) {
      return;
    }
    const formula = readRenderedFormula(node);
    if (formula) {
      const delimited = formula.display ? `$$${formula.tex}$$` : `$${formula.tex}$`;
      const normalized = normalizeLatexForNotion(delimited);
      node.replaceWith(document.createTextNode(normalized.text));
      return;
    }
    for (const child of Array.from(node.children)) {
      replaceMath(child);
    }
  };
  replaceMath(clone);

  clone.querySelectorAll("button, [role=\"button\"], script, style, svg, [aria-hidden=\"true\"]").forEach((element) => element.remove());
  const originalImages = Array.from(root.querySelectorAll("img"));
  const copiedImages = Array.from(clone.querySelectorAll("img"));
  copiedImages.forEach((image, index) => {
    const original = originalImages[index];
    const source = copyImageAsDataUrl(original) || original?.currentSrc || original?.src || original?.getAttribute("src");
    if (source) {
      image.setAttribute("src", source);
    }
    image.removeAttribute("srcset");
    for (const attribute of Array.from(image.attributes)) {
      if (attribute.name.toLowerCase().startsWith("on")) {
        image.removeAttribute(attribute.name);
      }
    }
  });
  return clone.innerHTML;
}

function copyImageAsDataUrl(image                 )                 {
  if (!image?.complete || !image.naturalWidth || !image.naturalHeight) {
    return undefined;
  }

  try {
    const canvas = document.createElement("canvas");
    canvas.width = image.naturalWidth;
    canvas.height = image.naturalHeight;
    const context = canvas.getContext("2d");
    if (!context) {
      return undefined;
    }
    context.drawImage(image, 0, 0);
    const dataUrl = canvas.toDataURL("image/png");
    return dataUrl.length <= 15_000_000 ? dataUrl : undefined;
  } catch {
    // Cross-origin images without CORS permission remain as source URLs in the HTML.
    return undefined;
  }
}

function serializeChildren(element         , state                       )         {
  return Array.from(element.childNodes)
    .map((node) => serializeNode(node, state))
    .join("");
}

function serializeNode(node      , state                       )         {
  if (node instanceof Text) {
    return node.data;
  }
  if (!(node instanceof HTMLElement)) {
    return "";
  }

  const formula = readRenderedFormula(node);
  if (formula) {
    state.mathCount += 1;
    return formula.display ? `\n\n$$${formula.tex}$$\n\n` : `$${formula.tex}$`;
  }

  const tag = node.tagName.toLowerCase();
  if (
    tag === "button" ||
    node.getAttribute("role") === "button" ||
    tag === "script" ||
    tag === "style" ||
    tag === "svg" ||
    node.getAttribute("aria-hidden") === "true"
  ) {
    return "";
  }
  if (tag === "img") {
    const source = node.currentSrc || node.src || node.getAttribute("src") || "";
    if (!source) {
      return node.getAttribute("alt") ?? "";
    }
    state.imageCount += 1;
    const alt = node.getAttribute("alt")?.trim() || "图片";
    return `\n\n![${alt}](${source})\n\n`;
  }
  if (/^h[1-6]$/.test(tag)) {
    const level = Number(tag[1]);
    return `\n\n${"#".repeat(level)} ${serializeChildren(node, state).trim()}\n\n`;
  }
  if (tag === "p") {
    return `\n\n${serializeChildren(node, state).trim()}\n\n`;
  }
  if (tag === "br") {
    return "\n";
  }
  if (tag === "hr") {
    return "\n\n---\n\n";
  }
  if (tag === "strong" || tag === "b") {
    return `**${serializeChildren(node, state)}**`;
  }
  if (tag === "em" || tag === "i") {
    return `*${serializeChildren(node, state)}*`;
  }
  if (tag === "code" && node.parentElement?.tagName.toLowerCase() !== "pre") {
    return `\`${node.textContent ?? ""}\``;
  }
  if (tag === "pre") {
    const code = node.querySelector("code");
    const language =
      code?.className.match(/language-([A-Za-z0-9_-]+)/)?.[1] ??
      node.getAttribute("data-language") ??
      "";
    return `\n\n\`\`\`${language}\n${code?.textContent ?? node.textContent ?? ""}\n\`\`\`\n\n`;
  }
  if (tag === "ul" || tag === "ol") {
    return `\n${serializeList(node, state, tag === "ol")}\n`;
  }
  if (tag === "blockquote") {
    const content = serializeChildren(node, state).trim();
    return `\n\n${content
      .split("\n")
      .map((line) => `> ${line}`)
      .join("\n")}\n\n`;
  }
  if (tag === "a") {
    const label = serializeChildren(node, state).trim();
    const href = node.getAttribute("href");
    return href ? `[${label}](${href})` : label;
  }
  if (tag === "table") {
    return `\n\n${serializeTable(node, state)}\n\n`;
  }

  return serializeChildren(node, state);
}

function serializeList(
  list             ,
  state                       ,
  ordered         
)         {
  return Array.from(list.children)
    .filter((child) => child.tagName.toLowerCase() === "li")
    .map((item, index) => {
      const marker = ordered ? `${index + 1}.` : "-";
      return `${marker} ${serializeChildren(item, state).trim()}`;
    })
    .join("\n");
}

function serializeTable(table             , state                       )         {
  const rows = Array.from(table.querySelectorAll("tr")).map((row) =>
    Array.from(row.children).map((cell) => serializeChildren(cell, state).trim())
  );
  if (rows.length === 0) {
    return "";
  }

  const width = Math.max(...rows.map((row) => row.length));
  const normalized = rows.map((row) => [
    ...row,
    ...Array.from({ length: width - row.length }, () => "")
  ]);
  const lines = normalized.map((row) => `| ${row.join(" | ")} |`);
  lines.splice(1, 0, `| ${Array.from({ length: width }, () => "---").join(" | ")} |`);
  return lines.join("\n");
}

function readRenderedFormula(
  element             
)                                                {
  const isDisplay = element.classList.contains("katex-display");
  const isKatex = element.classList.contains("katex");
  const isMathJax = element.tagName.toLowerCase() === "mjx-container";
  if (!isDisplay && !isKatex && !isMathJax) {
    return undefined;
  }

  if (isKatex && element.closest(".katex-display")) {
    return undefined;
  }

  const annotation = element.querySelector(
    'annotation[encoding*="application/x-tex" i]'
  );
  const tex = annotation?.textContent?.trim() ?? element.getAttribute("data-math")?.trim();
  return tex ? { tex, display: isDisplay || element.getAttribute("display") === "true" } : undefined;
}

})();
