(() => {
                                  
               
                   
                    
 

                         
               
                    
 

                     
               
                
                     
                      
                   
 

                                
               
              
 

const DELIMITERS              = [
  { open: "$$", close: "$$", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\[", close: "\\]", outputOpen: "$$", outputClose: "$$", display: true },
  { open: "\\(", close: "\\)", outputOpen: "$$", outputClose: "$$", display: false },
  { open: "$", close: "$", outputOpen: "$$", outputClose: "$$", display: false }
];

const STRUCTURED_LINE_BREAK_ENVIRONMENTS = new Set([
  "align",
  "align*",
  "aligned",
  "alignedat",
  "alignedat*",
  "array",
  "bmatrix",
  "Bmatrix",
  "cases",
  "dcases",
  "gather",
  "gather*",
  "gathered",
  "matrix",
  "multline",
  "multline*",
  "pmatrix",
  "rcases",
  "smallmatrix",
  "split",
  "subarray",
  "vmatrix",
  "Vmatrix"
]);

/**
 * Makes copied LaTeX compatible with Notion without changing surrounding prose.
 * Fenced and inline code are intentionally opaque.
 */
function normalizeLatexForNotion(input        )                  {
  const segments = splitFencedCode(input);
  let mathCount = 0;

  const text = segments
    .map((segment) => {
      if (segment.code) {
        return segment.text;
      }

      const repaired = repairCorruptedMathMarkdown(segment.text);
      const result = normalizeTextSegment(repaired);
      mathCount += result.mathCount;
      return result.text;
    })
    .join("");

  return {
    text,
    changed: text !== input,
    mathCount
  };
}

function splitFencedCode(input        )                                         {
  const lines = input.match(/[^\r\n]*(?:\r\n|\n|\r|$)/g)?.filter(Boolean) ?? [];
  const segments                                         = [];
  let buffer = "";
  let inFence = false;
  let fenceCharacter = "";
  let fenceLength = 0;

  const flush = (code         ) => {
    if (buffer) {
      segments.push({ text: buffer, code });
      buffer = "";
    }
  };

  for (const line of lines) {
    let openedThisLine = false;
    if (!inFence) {
      const opening = line.match(/^ {0,3}(`{3,}|~{3,})/);
      if (opening) {
        flush(false);
        inFence = true;
        openedThisLine = true;
        fenceCharacter = opening[1][0];
        fenceLength = opening[1].length;
      }
    }

    buffer += line;

    if (inFence && !openedThisLine) {
      const closingPattern = new RegExp(`^ {0,3}${escapeRegExp(fenceCharacter)}{${fenceLength},}\\s*$`);
      if (closingPattern.test(line.replace(/(?:\r\n|\n|\r)$/, ""))) {
        flush(true);
        inFence = false;
        fenceCharacter = "";
        fenceLength = 0;
      }
    }
  }

  flush(inFence);
  return segments;
}

function normalizeTextSegment(input        )                {
  let output = "";
  let mathCount = 0;
  let index = 0;

  while (index < input.length) {
    const bareBracketBlock = readBareBracketMathBlock(input, index);
    if (bareBracketBlock) {
      output += `$$${normalizeMathBody(bareBracketBlock.body, true)}$$`;
      mathCount += 1;
      index = bareBracketBlock.end;
      continue;
    }

    if (input[index] === "`") {
      const codeEnd = findInlineCodeEnd(input, index);
      if (codeEnd !== -1) {
        output += input.slice(index, codeEnd);
        index = codeEnd;
        continue;
      }
    }

    const delimiter = delimiterAt(input, index);
    if (!delimiter || !isValidOpening(input, index, delimiter)) {
      output += input[index];
      index += 1;
      continue;
    }

    const bodyStart = index + delimiter.open.length;
    const closingIndex = findClosingDelimiter(input, bodyStart, delimiter);
    if (closingIndex === -1) {
      output += input[index];
      index += 1;
      continue;
    }

    const body = input.slice(bodyStart, closingIndex);
    if (!isValidMathBody(body, delimiter.display)) {
      output += input[index];
      index += 1;
      continue;
    }

    const normalizedBody = normalizeMathBody(body, delimiter.display);
    output += `${delimiter.outputOpen}${normalizedBody}${delimiter.outputClose}`;
    mathCount += 1;
    index = closingIndex + delimiter.close.length;
  }

  return { text: output, mathCount };
}

function repairCorruptedMathMarkdown(input        )         {
  const proseUnwrapped = input.replace(/\$\$([^$\r\n]+)\$\$/g, (match, body        ) =>
    isPlainCjkProse(body) ? body.trim() : match
  );
  return repairDetachedSetextEquations(proseUnwrapped);
}

function isPlainCjkProse(body        )          {
  const trimmed = body.trim();
  return (
    /[\p{Script=Han}]/u.test(trimmed) &&
    !/[\\A-Za-z0-9_^=+\-*/<>{}[\]]/.test(trimmed)
  );
}

function repairDetachedSetextEquations(input        )         {
  const newline = input.match(/\r\n|\n|\r/)?.[0] ?? "\n";
  const lines = input.split(/\r\n|\n|\r/);

  for (let index = 0; index < lines.length; index += 1) {
    if (!/^[ \t]*={3,}[ \t]*$/.test(lines[index])) {
      continue;
    }

    const leftIndex = findNonEmptyLine(lines, index - 1, -1);
    const rightIndex = findNonEmptyLine(lines, index + 1, 1);
    if (leftIndex === -1 || rightIndex === -1) {
      continue;
    }

    const left = stripDisplayDelimiters(lines[leftIndex]);
    const firstRight = stripDisplayDelimiters(lines[rightIndex]);
    if (!looksLikeLatex(left) && !looksLikeLatex(firstRight)) {
      continue;
    }

    let start = leftIndex;
    if (leftIndex > 0 && lines[leftIndex - 1].trim() === "$$") {
      start = leftIndex - 1;
    }

    const end = findCorruptedFormulaEnd(lines, rightIndex);
    if (end === -1) {
      continue;
    }

    const right = lines
      .slice(rightIndex, end + 1)
      .map(stripDisplayDelimiters)
      .filter((line) => line.trim().length > 0)
      .join("\n");
    const formula = normalizeMathBody(`${left}\n=\n${right}`, true);
    lines.splice(start, end - start + 1, `$$${formula}$$`);
    index = start;
  }

  return lines.join(newline);
}

function findNonEmptyLine(
  lines          ,
  start        ,
  direction        
)         {
  for (let index = start; index >= 0 && index < lines.length; index += direction) {
    if (lines[index].trim()) {
      return index;
    }
  }
  return -1;
}

function findCorruptedFormulaEnd(lines          , rightIndex        )         {
  for (let index = rightIndex; index < lines.length; index += 1) {
    const trimmed = lines[index].trim();
    if (trimmed.includes("$$")) {
      return index;
    }
    if (index > rightIndex && !trimmed) {
      const next = findNonEmptyLine(lines, index + 1, 1);
      if (next === -1 || !looksLikeLatex(stripDisplayDelimiters(lines[next]))) {
        return -1;
      }
    }
  }
  return -1;
}

function stripDisplayDelimiters(value        )         {
  return value.replace(/^\s*\$\$|\$\$\s*$/g, "").trim();
}

function looksLikeLatex(value        )          {
  return /\\[A-Za-z]+|[_^{}]|[∫∑√∞≤≥≠≈]/.test(value);
}

function readBareBracketMathBlock(
  input        ,
  index        
)                                   {
  if (
    input[index] !== "[" ||
    (index > 0 && input[index - 1] !== "\n" && input[index - 1] !== "\r")
  ) {
    return undefined;
  }

  const match = input
    .slice(index)
    .match(/^\[[ \t]*(?:\r\n|\n|\r)([\s\S]*?)(?:\r\n|\n|\r)[ \t]*\](?=[ \t]*(?:\r\n|\n|\r|$))/);
  if (!match || !isLikelyBareBracketMath(match[1])) {
    return undefined;
  }

  return {
    body: match[1],
    end: index + match[0].length
  };
}

function isLikelyBareBracketMath(body        )          {
  if (!isValidMathBody(body, true)) {
    return false;
  }

  const trimmed = body.trim();
  return (
    /\\[A-Za-z]+/.test(trimmed) ||
    /[_^=]/.test(trimmed) ||
    /[∫∑√∞≤≥≠≈→←]/.test(trimmed)
  );
}

function delimiterAt(input        , index        )                        {
  if (isEscaped(input, index)) {
    return undefined;
  }

  return DELIMITERS.find((delimiter) => input.startsWith(delimiter.open, index));
}

function isValidOpening(input        , index        , delimiter           )          {
  if (delimiter.open !== "$") {
    return true;
  }

  const previous = input[index - 1] ?? "";
  const next = input[index + 1] ?? "";
  return !/[A-Za-z0-9\\]/.test(previous) && next !== "$" && !/\s/.test(next);
}

function findClosingDelimiter(input        , start        , delimiter           )         {
  for (let index = start; index <= input.length - delimiter.close.length; index += 1) {
    if (!input.startsWith(delimiter.close, index) || isEscaped(input, index)) {
      continue;
    }

    if (
      delimiter.close === "$$" &&
      hasUnclosedStructuredEnvironment(input.slice(start, index))
    ) {
      continue;
    }

    if (delimiter.close === "$" && input[index + 1] === "$") {
      continue;
    }

    if (delimiter.close === "$") {
      const previous = input[index - 1] ?? "";
      const next = input[index + 1] ?? "";
      if (/\s/.test(previous) || /[0-9]/.test(next)) {
        continue;
      }
    }

    return index;
  }

  return -1;
}

function isValidMathBody(body        , allowBlankLines = false)          {
  const trimmed = body.trim();
  const normalizedLineEndings = trimmed.replace(/\r\n?|\u2028|\u2029/g, "\n");
  return trimmed.length > 0 && (allowBlankLines || !/\n[ \t]*\n/.test(normalizedLineEndings));
}

function normalizeMathBody(body        , display         )         {
  const repaired = display ? repairDisplayClipboardArtifacts(body) : body;
  const structured = repairStructuredEnvironmentLineBreaks(repaired);
  const collapsed = normalizeRowBreakArtifacts(collapsePhysicalLineBreaks(structured));
  return display
    ? collapsed.replace(/(^|[ \t])=(?:[ \t]+=)+(?=[ \t]|$)/g, "$1=")
    : collapsed;
}

function repairDisplayClipboardArtifacts(body        )         {
  return body
    .replace(/\r\n?|\u2028|\u2029/g, "\n")
    .replace(/[ \t]*\$\$(?=\\end\{[A-Za-z*]+\})/g, " ")
    .replace(/^[ \t]*={3,}[ \t]*$/gm, "=")
    .replace(/^[ \t]*#{1,6}[ \t]+(?=\\)/gm, "= ")
    .replace(/(^|[ \t])={2,}(?=[ \t]|$)/g, "$1=");
}

function hasUnclosedStructuredEnvironment(body        )          {
  const stack           = [];
  const pattern = /\\(begin|end)\{([^}]+)\}/g;
  let match                        ;
  while ((match = pattern.exec(body))) {
    const [, kind, environment] = match;
    if (!STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(environment)) {
      continue;
    }

    if (kind === "begin") {
      stack.push(environment);
      continue;
    }

    const lastIndex = stack.lastIndexOf(environment);
    if (lastIndex !== -1) {
      stack.splice(lastIndex, 1);
    }
  }

  return stack.length > 0;
}

function collapsePhysicalLineBreaks(body        )         {
  return body
    .replace(/\r\n?|\u2028|\u2029/g, "\n")
    .replace(/[ \t]*\n+[ \t]*/g, " ")
    .replace(/(^|[ \t])={3,}(?=[ \t]|$)/g, "$1=")
    .trim();
}

function repairStructuredEnvironmentLineBreaks(body        )         {
  const normalized = body.replace(/\r\n?|\u2028|\u2029/g, "\n");
  if (!/\\(?:begin|end)\{/.test(normalized)) {
    return normalized;
  }

  const lines = normalized.split("\n");
  const environmentStack           = [];
  return lines
    .map((line, index) => {
      const trimmed = line.trim();
      const insideBefore = environmentStack.length > 0;
      updateStructuredEnvironmentStack(environmentStack, trimmed);
      const insideAfter = environmentStack.length > 0;

      if (
        !trimmed ||
        (!insideBefore && !insideAfter) ||
        isOnlyStructuredEnvironmentBoundary(trimmed) ||
        !hasFollowingStructuredEnvironmentRow(lines, index + 1)
      ) {
        return line;
      }

      if (hasTrailingSingleBackslash(trimmed)) {
        return `${line.trimEnd()}\\`;
      }

      if (hasExplicitLatexLineBreak(trimmed)) {
        return line;
      }

      return `${line.trimEnd()} \\\\`;
    })
    .join("\n");
}

function updateStructuredEnvironmentStack(stack          , line        )       {
  const pattern = /\\(begin|end)\{([^}]+)\}/g;
  let match                        ;
  while ((match = pattern.exec(line))) {
    const [, kind, environment] = match;
    if (!STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(environment)) {
      continue;
    }

    if (kind === "begin") {
      stack.push(environment);
    } else {
      const lastIndex = stack.lastIndexOf(environment);
      if (lastIndex !== -1) {
        stack.splice(lastIndex, 1);
      }
    }
  }
}

function isOnlyStructuredEnvironmentBoundary(line        )          {
  const match = line.match(/^\\(?:begin|end)\{([^}]+)\}$/);
  return !!match && STRUCTURED_LINE_BREAK_ENVIRONMENTS.has(match[1]);
}

function hasExplicitLatexLineBreak(line        )          {
  return /\\\\(?:\[[^\]]*\])?\s*$|\\cr\s*$/.test(line);
}

function hasTrailingSingleBackslash(line        )          {
  const match = line.match(/\\+$/);
  return match?.[0].length === 1;
}

function normalizeRowBreakArtifacts(body        )         {
  return body.replace(/\\[ \t]+\\\\/g, "\\\\");
}

function hasFollowingStructuredEnvironmentRow(lines          , start        )          {
  for (let index = start; index < lines.length; index += 1) {
    const trimmed = lines[index].trim();
    if (!trimmed) {
      continue;
    }
    return !/^\\end\{([^}]+)\}$/.test(trimmed);
  }
  return false;
}

function findInlineCodeEnd(input        , start        )         {
  let markerLength = 1;
  while (input[start + markerLength] === "`") {
    markerLength += 1;
  }

  const marker = "`".repeat(markerLength);
  const end = input.indexOf(marker, start + markerLength);
  return end === -1 ? -1 : end + markerLength;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function escapeRegExp(value        )         {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

                               
               
                   
 

                                     
                 
                  
 

                                  
               
                                 
 

                                 
                     
                      
                   
                    
 

/**
 * Replaces formulas with plain, Markdown-safe markers for the first paste.
 * Once Notion has created its blocks, each marker can be selected and replaced
 * through the same single-formula paste path that Notion already understands.
 */
function buildNotionPastePlan(input        , token = createPasteToken())                  {
  const formulas                       = [];
  let previousWasFormula = false;
  const text = splitNotionPasteSegments(input)
    .map((segment) => {
      if (!segment.formula) {
        previousWasFormula = false;
        return segment.text;
      }

      const marker = `NLTX${token}X${formulas.length}X`;
      formulas.push({ marker, formula: segment.text });
      const separator = previousWasFormula ? "\n" : "";
      previousWasFormula = true;
      return `${separator}${marker}`;
    })
    .join("");

  return { text, formulas };
}

/** Maps a marker in concatenated DOM text back to its individual text nodes. */
function findMarkerTextSpan(
  chunks          ,
  marker        
)                             {
  if (!marker) {
    return undefined;
  }

  const markerStart = chunks.join("").indexOf(marker);
  if (markerStart === -1) {
    return undefined;
  }

  const start = locateChunkOffset(chunks, markerStart, true);
  const end = locateChunkOffset(chunks, markerStart + marker.length, false);
  if (!start || !end) {
    return undefined;
  }

  return {
    startChunk: start.chunk,
    startOffset: start.offset,
    endChunk: end.chunk,
    endOffset: end.offset
  };
}

function normalizeFormulaSource(value        )         {
  let text = value.trim();
  const delimiterPairs                          = [
    ["$$", "$$"],
    ["$", "$"],
    ["\\[", "\\]"],
    ["\\(", "\\)"]
  ];

  for (const [open, close] of delimiterPairs) {
    if (text.startsWith(open) && text.endsWith(close) && text.length >= open.length + close.length) {
      text = text.slice(open.length, text.length - close.length).trim();
      break;
    }
  }

  return text.replace(/\s+/g, "");
}

/** Splits normalized Markdown while leaving fenced and inline code untouched. */
function splitNotionPasteSegments(input        )                 {
  const segments                 = [];
  let textStart = 0;
  let index = 0;
  let inlineCodeMarker = "";
  let fenceMarker = "";
  let lineStart = true;

  while (index < input.length) {
    if (lineStart && !inlineCodeMarker) {
      const fence = readFence(input, index);
      if (fence) {
        if (!fenceMarker) {
          fenceMarker = fence;
        } else if (fence[0] === fenceMarker[0] && fence.length >= fenceMarker.length) {
          fenceMarker = "";
        }
        index += fence.length;
        lineStart = false;
        continue;
      }
    }

    if (!fenceMarker && input[index] === "`") {
      const marker = readRepeated(input, index, "`");
      if (!inlineCodeMarker) {
        inlineCodeMarker = marker;
      } else if (marker === inlineCodeMarker) {
        inlineCodeMarker = "";
      }
      index += marker.length;
      lineStart = false;
      continue;
    }

    if (!fenceMarker && !inlineCodeMarker && input.startsWith("$$", index)) {
      const end = findFormulaEnd(input, index + 2);
      if (end !== -1) {
        pushSegment(segments, input.slice(textStart, index), false);
        pushSegment(segments, input.slice(index, end + 2), true);
        index = end + 2;
        textStart = index;
        lineStart = false;
        continue;
      }
    }

    if (input[index] === "\n" || input[index] === "\r") {
      if (input[index] === "\r" && input[index + 1] === "\n") {
        index += 1;
      }
      lineStart = true;
    } else {
      lineStart = false;
    }
    index += 1;
  }

  pushSegment(segments, input.slice(textStart), false);
  return mergeAdjacentText(segments);
}

function readFence(input        , index        )                     {
  let cursor = index;
  let spaces = 0;
  while (input[cursor] === " " && spaces < 3) {
    cursor += 1;
    spaces += 1;
  }
  const character = input[cursor];
  if (character !== "`" && character !== "~") {
    return undefined;
  }
  const marker = readRepeated(input, cursor, character);
  return marker.length >= 3 ? marker : undefined;
}

function readRepeated(input        , index        , character        )         {
  let cursor = index;
  while (input[cursor] === character) {
    cursor += 1;
  }
  return input.slice(index, cursor);
}

function findFormulaEnd(input        , start        )         {
  for (let index = start; index < input.length - 1; index += 1) {
    if (input.startsWith("$$", index) && !isEscaped(input, index)) {
      return index;
    }
  }
  return -1;
}

function isEscaped(input        , index        )          {
  let slashCount = 0;
  for (let cursor = index - 1; cursor >= 0 && input[cursor] === "\\"; cursor -= 1) {
    slashCount += 1;
  }
  return slashCount % 2 === 1;
}

function pushSegment(segments                , text        , formula         )       {
  if (text) {
    segments.push({ text, formula });
  }
}

function mergeAdjacentText(segments                )                 {
  const result                 = [];
  for (const segment of segments) {
    const previous = result[result.length - 1];
    if (previous && !previous.formula && !segment.formula) {
      previous.text += segment.text;
    } else {
      result.push({ ...segment });
    }
  }
  return result;
}

function createPasteToken()         {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).slice(2, 8).toUpperCase();
  return `${timestamp}${random}`;
}

function locateChunkOffset(
  chunks          ,
  absoluteOffset        ,
  preferNextAtBoundary         
)                                                {
  let consumed = 0;
  for (let index = 0; index < chunks.length; index += 1) {
    const next = consumed + chunks[index].length;
    if (
      absoluteOffset < next ||
      (absoluteOffset === next && (!preferNextAtBoundary || index === chunks.length - 1))
    ) {
      return { chunk: index, offset: absoluteOffset - consumed };
    }
    consumed = next;
  }
  return undefined;
}

                                    
                                     
                                
 

const PLAIN_TEXT_TYPES = ["text/plain", "Text", "text", "text/markdown"];

function readClipboardText(data                   )         {
  for (const type of getPlainTextTypes(data)) {
    const value = data.getData(type);
    if (value) {
      return value;
    }
  }

  const html = data.getData("text/html");
  return html ? extractTextFromHtml(html) : "";
}

function getPlainTextTypes(data                   )           {
  const advertised = Array.from(data.types ?? []);
  const advertisedPlainTypes = advertised.filter((type) => {
    const normalized = type.toLowerCase();
    return normalized === "text" || normalized.startsWith("text/plain");
  });

  return [...new Set([...PLAIN_TEXT_TYPES, ...advertisedPlainTypes])];
}

function extractTextFromHtml(html        )         {
  if (typeof DOMParser === "undefined") {
    return "";
  }

  const parsed = new DOMParser().parseFromString(html, "text/html");
  parsed.querySelectorAll("br").forEach((element) => element.replaceWith("\n"));
  parsed
    .querySelectorAll("p, div, li, h1, h2, h3, h4, h5, h6, pre, blockquote")
    .forEach((element) => {
      element.prepend("\n");
      element.append("\n");
    });

  return (parsed.body.textContent ?? "")
    .replace(/\r\n|\r/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}




let redispatchingPaste = false;

document.documentElement.dataset.notionLatexPasteVersion = "0.6.14";

                                
                           
 

                                   
                              
                               
 

window.addEventListener(
  "paste",
  (event) => {
    if (redispatchingPaste || !event.clipboardData) {
      return;
    }

    const originalText = readClipboardText(event.clipboardData);
    if (!originalText) {
      return;
    }

    const result = normalizeLatexForNotion(originalText);
    if (result.mathCount === 0) {
      return;
    }

    const target = getDispatchTarget(event);
    if (!target) {
      return;
    }

    event.preventDefault();
    event.stopImmediatePropagation();

    const plan = buildNotionPastePlan(result.text);
    const clipboardHtml = event.clipboardData.getData("text/html");
    const placeholderHtml = clipboardHtml && hasClipboardImage(clipboardHtml)
      ? buildNotionHtmlPastePlan(clipboardHtml, plan.formulas)
      : undefined;
    void pasteWithFormulaPlaceholders(target, plan.text, plan.formulas, placeholderHtml);
  },
  true
);

function getDispatchTarget(event                )                 {
  const pathTarget = event.composedPath()[0];
  if (pathTarget instanceof Element) {
    return pathTarget;
  }
  return event.target instanceof Element ? event.target : document.activeElement;
}

function insertPlainTextFallback(text        )       {
  // execCommand keeps contenteditable frameworks in sync better than direct DOM mutation.
  document.execCommand("insertText", false, text);
}

function hasClipboardImage(html        )          {
  if (typeof DOMParser === "undefined") {
    return /<img\b/i.test(html);
  }
  return new DOMParser().parseFromString(html, "text/html").querySelector("img") !== null;
}

function buildNotionHtmlPastePlan(html        , formulas                      )                        {
  if (!html || formulas.length === 0 || typeof DOMParser === "undefined") {
    return undefined;
  }

  const parsed = new DOMParser().parseFromString(html, "text/html");
  parsed.body.querySelectorAll("script, style, iframe, object, embed").forEach((element) => element.remove());
  for (const element of parsed.body.querySelectorAll("*")) {
    for (const attribute of Array.from(element.attributes)) {
      const name = attribute.name.toLowerCase();
      const value = attribute.value.trim().toLowerCase();
      if (name.startsWith("on") || ((name === "href" || name === "src") && value.startsWith("javascript:"))) {
        element.removeAttribute(attribute.name);
      }
    }
  }

  const walker = document.createTreeWalker(parsed.body, NodeFilter.SHOW_TEXT);
  const textNodes = [];
  let current = walker.nextNode();
  while (current) {
    if (!current.parentElement?.closest("code, pre, script, style")) {
      textNodes.push(current);
    }
    current = walker.nextNode();
  }

  let formulaIndex = 0;
  for (const textNode of textNodes) {
    let text = textNode.data;
    let cursor = 0;
    let changed = false;
    while (formulaIndex < formulas.length) {
      const formula = formulas[formulaIndex];
      const index = text.indexOf(formula.formula, cursor);
      if (index === -1) {
        break;
      }
      text = `${text.slice(0, index)}${formula.marker}${text.slice(index + formula.formula.length)}`;
      cursor = index + formula.marker.length;
      formulaIndex += 1;
      changed = true;
    }
    if (changed) {
      textNode.data = text;
    }
  }

  return formulaIndex === formulas.length ? parsed.body.innerHTML : undefined;
}

async function pasteWithFormulaPlaceholders(
  initialTarget         ,
  placeholderText        ,
  formulas                      ,
  placeholderHtml
)                {
  redispatchingPaste = true;
  let convertedCount = 0;
  const attemptedMarkers = new Set        ();
  try {
    dispatchPlainTextPaste(initialTarget, placeholderText, { html: placeholderHtml });
    await waitForInitialPaste(formulas);

    for (const formula of formulas) {
      try {
        const target = await selectMarker(formula.marker);
        if (!target) {
          continue;
        }

        attemptedMarkers.add(formula.marker);
        const beforeFormulaPaste = getRenderedFormulaSnapshot();
        dispatchPlainTextPaste(target, formula.formula, { insertFallback: false });
        if (await waitForFormulaPasteResult(formula, beforeFormulaPaste)) {
          convertedCount += 1;
          // Notion removes the marker before its equation block has completely
          // settled. Starting the next replacement immediately can steal focus.
          await waitForEditorUpdate(140);
        }
      } catch (error) {
        console.warn("Notion LaTeX replacement failed", error);
        if (attemptedMarkers.has(formula.marker)) {
          await removeMarkerText(formula);
        } else {
          await replaceMarkerWithRawFormula(formula);
        }
      }
    }

    await cleanRemainingMarkers(formulas, attemptedMarkers);
    showConvertedToast(convertedCount, formulas.length);
  } finally {
    redispatchingPaste = false;
  }
}

async function waitForInitialPaste(formulas                      )                {
  const lastFormula = formulas[formulas.length - 1];
  if (!lastFormula) {
    return;
  }

  const deadline = Date.now() + 5000;
  while (Date.now() < deadline) {
    // Notion creates pasted blocks in document order. Seeing the last marker
    // means it has finished materializing the response before replacements
    // start changing focus and block types.
    if (findMarker(lastFormula.marker)) {
      await waitForEditorUpdate(120);
      return;
    }
    await waitForEditorUpdate(25);
  }
}

function dispatchPlainTextPaste(
  target         ,
  text        ,
  options                       = {}
)       {
  const clipboardData = new DataTransfer();
  clipboardData.setData("text/plain", text);
  if (options.html) {
    clipboardData.setData("text/html", options.html);
  }
  const replacementEvent = new ClipboardEvent("paste", {
    bubbles: true,
    cancelable: true,
    composed: true,
    clipboardData
  });

  const notCancelled = target.dispatchEvent(replacementEvent);
  if (notCancelled && options.insertFallback !== false) {
    insertPlainTextFallback(text);
  }
}

async function selectMarker(marker        )                                   {
  const deadline = Date.now() + 2500;
  while (Date.now() < deadline) {
    const match = findMarker(marker);
    if (match) {
      match.editable.focus({ preventScroll: true });
      const selection = document.getSelection();
      if (!selection) {
        return undefined;
      }
      selection.removeAllRanges();
      selection.addRange(match.range);
      return match.editable;
    }

    await waitForEditorUpdate(25);
  }

  return undefined;
}

function findMarker(marker        )                                                      {
  const editables = document.querySelectorAll             ('[contenteditable="true"]');
  for (const editable of editables) {
    const nodes = collectOwnedTextNodes(editable);
    const span = findMarkerTextSpan(nodes.map((node) => node.data), marker);
    if (!span) {
      continue;
    }

    const range = document.createRange();
    range.setStart(nodes[span.startChunk], span.startOffset);
    range.setEnd(nodes[span.endChunk], span.endOffset);
    return { editable, range };
  }
  return undefined;
}

function collectOwnedTextNodes(editable             )         {
  const nodes         = [];
  const walker = document.createTreeWalker(editable, NodeFilter.SHOW_TEXT);
  let current = walker.nextNode();
  while (current) {
    if (
      current instanceof Text &&
      current.data.length > 0 &&
      current.parentElement?.closest('[contenteditable="true"]') === editable
    ) {
      nodes.push(current);
    }
    current = walker.nextNode();
  }
  return nodes;
}

async function waitForFormulaPasteResult(
  formula                    ,
  beforeFormulaPaste                         
)                   {
  const deadline = Date.now() + 2200;
  while (Date.now() < deadline) {
    if (hasRenderedFormula(formula, beforeFormulaPaste)) {
      await removeMarkerText(formula);
      return true;
    }

    if (!findMarker(formula.marker)) {
      // Notion removes the selected marker before its equation block settles.
      // Keep waiting for the matching TeX annotation instead of treating any
      // unrelated KaTeX render elsewhere on the page as success.
      await waitForEditorUpdate(80);
      continue;
    }

    await waitForEditorUpdate(20);
  }

  // Notion can insert the equation block but leave the selected placeholder
  // behind. Replacing it with raw "$$...$$" would duplicate the formula.
  if (hasRenderedFormula(formula, beforeFormulaPaste)) {
    await removeMarkerText(formula);
    return true;
  }

  await replaceMarkerWithRawFormula(formula);
  return false;
}

async function replaceMarkerWithRawFormula(formula                    )                {
  const target = await selectMarker(formula.marker);
  if (target) {
    document.execCommand("insertText", false, formula.formula);
    await waitForEditorUpdate(40);
  }
}

async function removeMarkerText(formula                    )                   {
  const target = await selectMarker(formula.marker);
  if (!target) {
    return false;
  }

  document.execCommand("delete", false);
  await waitForEditorUpdate(40);
  return !findMarker(formula.marker);
}

async function cleanRemainingMarkers(
  formulas                      ,
  attemptedMarkers             
)                {
  for (const formula of formulas) {
    if (!findMarker(formula.marker)) {
      continue;
    }

    if (attemptedMarkers.has(formula.marker)) {
      await removeMarkerText(formula);
    } else {
      await replaceMarkerWithRawFormula(formula);
    }
  }
}

function getRenderedFormulaSnapshot()                          {
  return {
    katexElements: new Set(document.querySelectorAll(".katex")),
    texAnnotations: new Set(getTexAnnotations())
  };
}

function hasRenderedFormula(
  formula                    ,
  beforeFormulaPaste                         
)          {
  const expected = normalizeFormulaSource(formula.formula);
  if (!expected) {
    return false;
  }

  for (const annotation of getTexAnnotations()) {
    if (
      !beforeFormulaPaste.texAnnotations.has(annotation) &&
      normalizeFormulaSource(annotation.textContent ?? "") === expected
    ) {
      return true;
    }
  }

  // Some Notion builds omit the TeX annotation. In that case only accept a
  // newly-created KaTeX node after the selected marker has disappeared.
  return (
    !findMarker(formula.marker) &&
    Array.from(document.querySelectorAll(".katex")).some(
      (element) => !beforeFormulaPaste.katexElements.has(element)
    )
  );
}

function getTexAnnotations()            {
  return Array.from(document.querySelectorAll("annotation")).filter((annotation) => {
    const encoding = annotation.getAttribute("encoding") ?? "";
    return encoding.toLowerCase().includes("application/x-tex");
  });
}

function waitForEditorUpdate(delay        )                {
  return new Promise((resolve) => window.setTimeout(resolve, delay));
}

function showConvertedToast(convertedCount        , mathCount        )       {
  const existing = document.getElementById("notion-latex-paste-toast");
  existing?.remove();

  const toast = document.createElement("div");
  toast.id = "notion-latex-paste-toast";
  const complete = convertedCount === mathCount;
  toast.textContent = complete
    ? `已转换 ${mathCount} 个 LaTeX 公式`
    : `已转换 ${convertedCount}/${mathCount} 个公式，未转换的已保留原文`;
  Object.assign(toast.style, {
    position: "fixed",
    right: "20px",
    bottom: "20px",
    zIndex: "2147483647",
    padding: "9px 12px",
    borderRadius: "7px",
    background: complete ? "#238636" : "#b45309",
    color: "white",
    font: "13px -apple-system, BlinkMacSystemFont, sans-serif",
    boxShadow: "0 4px 18px rgba(0, 0, 0, 0.22)",
    pointerEvents: "none"
  });
  document.documentElement.appendChild(toast);
  window.setTimeout(() => toast.remove(), 1800);
}

})();
